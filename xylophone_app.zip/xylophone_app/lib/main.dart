import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

void main() => runApp(const XylophoneApp());

class XylophoneApp extends StatefulWidget {
  const XylophoneApp({super.key});

  @override
  State<XylophoneApp> createState() => _XylophoneAppState();
}

class _XylophoneAppState extends State<XylophoneApp> {
  final player = AudioPlayer();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              CreateButton(Colors.blue, 1),
              CreateButton(Colors.redAccent, 2),
              CreateButton(Colors.green, 3),
              CreateButton(Colors.orange, 4),
              CreateButton(Colors.yellow, 5),
              CreateButton(Colors.pink, 6),
              CreateButton(Colors.purple, 7),
            ],
          ),
        ),
      ),
    );
  }

  void PlaySound(int index) {
    setState(() {
      player.play(AssetSource('note$index.wav'));
    });
  }

  Expanded CreateButton(Color color, int index) {
    return Expanded(
      child: ElevatedButton(
        //button  1
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
        ),
        child: Text(''),
        onPressed: () {
          PlaySound(index);
        },
      ),
    );
  }
}
