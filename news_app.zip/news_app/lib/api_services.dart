import 'dart:convert';

import 'package:http/http.dart' as http;

class ApiServices {
  Future fetchData() async {
    final response = await http.get(Uri.parse(
        'https://gnews.io/api/v4/top-headlines?token=4a2266fc321481dd683d7a441ef943f5&topic=technology&lang=en&country=gb'));
    if (response.statusCode == 200) {}
    var data = jsonDecode(response.body);
    return data;
  }
}
