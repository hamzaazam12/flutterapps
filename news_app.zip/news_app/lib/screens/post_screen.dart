import 'package:flutter/material.dart';

// ignore: must_be_immutable
class PostScreen extends StatelessWidget {
  String? title;
  String? imageUrl;
  String? content;
  String? name;
  PostScreen({super.key, this.content, this.title, this.imageUrl, this.name});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(name.toString()),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: ListView(
          children: [
            Image.network(imageUrl.toString()),
            const SizedBox(height: 30),
            Text(
              title.toString(),
              style: TextStyle(fontSize: 30, letterSpacing: 0),
            ),
            const SizedBox(height: 10),
            Text(
              content.toString(),
              style: const TextStyle(
                fontSize: 20,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
