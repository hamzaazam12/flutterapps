import 'package:flutter/material.dart';
import 'package:news_app/api_services.dart';
import 'package:news_app/screens/post_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final apiData = ApiServices();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Top Tech News'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: FutureBuilder(
              future: apiData.fetchData(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return Center(
                      child:
                          Container(child: const CircularProgressIndicator()));
                } else {
                  return ListView.builder(
                      itemCount: snapshot.data['articles'].length,
                      itemBuilder: ((context, index) {
                        return Column(
                          children: [
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => PostScreen(
                                            title: snapshot.data['articles']
                                                [index]['title'],
                                            imageUrl: snapshot.data['articles']
                                                [index]['image'],
                                            content: snapshot.data['articles']
                                                [index]['description'],
                                            name: snapshot.data['articles']
                                                [index]['source']['name'],
                                          )),
                                );
                              },
                              child: Card(
                                borderOnForeground: true,
                                elevation: 8,
                                child: Column(
                                  children: [
                                    Image.network(snapshot.data['articles']
                                        [index]['image']),
                                    Text(
                                      snapshot.data['articles'][index]['title']
                                          .toString(),
                                      style: const TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 30,
                            )
                          ],
                        );
                      }));
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}
