class PostScreenData {
  final String title;
  final String imageUrl;
  final String content;

  PostScreenData({
    required this.imageUrl,
    required this.title,
    required this.content,
  });
}
