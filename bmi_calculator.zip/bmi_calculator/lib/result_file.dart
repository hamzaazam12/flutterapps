import 'package:bmi_calculator/constant_file.dart';
import 'package:bmi_calculator/input_page.dart';
import 'package:flutter/material.dart';
import './container_repeated.dart';

class ResultScreen extends StatelessWidget {
  final String bmiResult;
  final String resultText;
  final String interpretation;

  ResultScreen(
      {required this.bmiResult,
      required this.resultText,
      required this.interpretation});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BMI Result'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Container(
              child: Center(
                child: Text(
                  'Your Result',
                  style: kResultText,
                  // style: kt,
                ),
              ),
            ),
          ),
          Expanded(
            flex: 5,
            child: ContainerRepeated(
              color: activeColor,
              widget: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    resultText.toUpperCase(),
                    style: TextStyle(
                      color: Colors.lightGreenAccent,
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    bmiResult,
                    style: kResultText,
                  ),
                  Text(
                    interpretation,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                    ),
                  )
                ],
              ),
            ),
          ),
          Expanded(
            child: GestureDetector(
              onTap: () {
                Navigator.pop(
                  context,
                  MaterialPageRoute(builder: (context) {
                    return InputPage();
                  }),
                );
              },
              child: Container(
                color: Color(0xFFEB1555),
                margin: EdgeInsets.only(top: 15),
                width: double.infinity,
                height: 60,
                child: Center(
                  child: Text(
                    'ReCalculate',
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
