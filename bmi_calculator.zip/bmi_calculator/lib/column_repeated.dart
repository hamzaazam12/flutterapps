import 'package:bmi_calculator/constant_file.dart';
import 'package:flutter/material.dart';

class ColumnRepeated extends StatelessWidget {
  String label;
  IconData iconData;

  ColumnRepeated({required this.label, required this.iconData});
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          iconData,
          size: 80,
        ),
        Text(
          label,
          style: kLableStyle,
        ),
      ],
    );
  }
}
