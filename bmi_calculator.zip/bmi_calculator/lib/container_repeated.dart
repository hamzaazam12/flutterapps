import 'package:flutter/material.dart';

class ContainerRepeated extends StatelessWidget {
  Color? color;
  Widget? widget;
  ContainerRepeated({this.widget, this.color});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(10),
      ),
      margin: EdgeInsets.all(15),
      child: widget,
    );
  }
}
