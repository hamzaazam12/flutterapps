import 'package:flutter/material.dart';

const activeColor = Color(0xFF1D1E33);
const deactiveColor = Color(0xFF111328);
const kLableStyle = TextStyle(
  fontSize: 24,
);

const kResultText = TextStyle(
  fontSize: 50,
  fontWeight: FontWeight.bold,
);
