import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import './column_repeated.dart';
import './container_repeated.dart';
import './constant_file.dart';
import './result_file.dart';
import './calculator_file.dart';

enum Gender {
  male,
  female,
}

class InputPage extends StatefulWidget {
  @override
  _InputPageState createState() => _InputPageState();
}

class _InputPageState extends State<InputPage> {
  Gender? selectGender;
  int sliderHeight = 180;
  int sliderWeight = 60;
  int sliderAge = 20;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BMI CALCULATOR'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Row(
              children: [
                Expanded(
                    child: GestureDetector(
                  onTap: () {
                    setState(() {
                      selectGender = Gender.male;
                    });
                  },
                  child: ContainerRepeated(
                    color: selectGender == Gender.male
                        ? activeColor
                        : deactiveColor,
                    widget: ColumnRepeated(
                      iconData: Icons.male,
                      label: 'MALE',
                    ),
                  ),
                )),
                Expanded(
                    child: GestureDetector(
                  onTap: () {
                    setState(() {
                      selectGender = Gender.female;
                    });
                  },
                  child: ContainerRepeated(
                    color: selectGender == Gender.female
                        ? activeColor
                        : deactiveColor,
                    widget: ColumnRepeated(
                      iconData: Icons.female,
                      label: 'FEMALE',
                    ),
                  ),
                ))
              ],
            ),
          ),
          Expanded(
              //Row 2.............
              child: ContainerRepeated(
            color: Color(0xFF1D1E33),
            widget: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'HEIGHT',
                  style: kLableStyle,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      sliderHeight.toString(),
                      style: TextStyle(
                        fontSize: 50,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    Text(
                      'cm',
                      style: kLableStyle,
                    )
                  ],
                ),
                Slider(
                  value: sliderHeight.toDouble(),
                  min: 120,
                  max: 220,
                  activeColor: Color(0xFFEB1555),
                  inactiveColor: Color(0xFF8D8E98),
                  onChanged: (newValue) {
                    setState(() {
                      sliderHeight = newValue.round();
                    });
                  },
                ),
              ],
            ),
            // widget: ,
          )),
          Expanded(
            child: Row(
              //3rd row........
              children: [
                Expanded(
                    child: ContainerRepeated(
                  color: Color(0xFF1D1E33),
                  widget: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'WEIGHT',
                        style: kLableStyle,
                      ),
                      Text(
                        sliderWeight.toString(),
                        style: TextStyle(
                          fontSize: 50,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          RoundIcon(
                              iconData: FontAwesomeIcons.minus,
                              onPressed: () {
                                setState(() {
                                  sliderWeight--;
                                });
                              }),
                          SizedBox(
                            width: 10,
                          ),
                          RoundIcon(
                              iconData: FontAwesomeIcons.plus,
                              onPressed: () {
                                setState(() {
                                  sliderWeight++;
                                });
                              })
                        ],
                      ),
                    ],
                  ),
                )),
                Expanded(
                  child: ContainerRepeated(
                    color: Color(0xFF1D1E33),
                    widget: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'AGE',
                          style: kLableStyle,
                        ),
                        Text(
                          sliderAge.toString(),
                          style: TextStyle(
                            fontSize: 50,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            RoundIcon(
                                iconData: FontAwesomeIcons.minus,
                                onPressed: () {
                                  setState(() {
                                    sliderAge--;
                                  });
                                }),
                            SizedBox(
                              width: 10,
                            ),
                            RoundIcon(
                                iconData: FontAwesomeIcons.plus,
                                onPressed: () {
                                  setState(() {
                                    sliderAge++;
                                  });
                                })
                          ],
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              Calculator result =
                  Calculator(height: sliderHeight, weight: sliderWeight);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) {
                  return ResultScreen(
                    bmiResult: result.Calculate(),
                    resultText: result.getResult(),
                    interpretation: result.getInterpretation(),
                  );
                }),
              );
            },
            child: Container(
              color: Color(0xFFEB1555),
              margin: EdgeInsets.only(top: 10),
              width: double.infinity,
              height: 60,
              child: Center(
                child: Text(
                  'Calculate',
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class RoundIcon extends StatelessWidget {
  final IconData iconData;
  final VoidCallback onPressed;

  RoundIcon({required this.iconData, required this.onPressed});
  @override
  Widget build(BuildContext context) {
    return RawMaterialButton(
      child: Icon(iconData),
      onPressed: onPressed,
      elevation: 6.0,
      constraints: BoxConstraints.tightFor(
        height: 56.0,
        width: 56.0,
      ),
      shape: CircleBorder(),
      fillColor: Color(0xFF4C4F5E),
    );
  }
}
//Color(0xFF1D1E33)
