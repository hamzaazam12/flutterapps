import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  List<bool> _selection = [true, false, false];

  String? tip;
  final enteredAmount = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (tip != null)
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Text(
                    tip as String,
                    style: TextStyle(fontSize: 30),
                  ),
                ),
              Text('Enter Amount'),
              SizedBox(
                width: 70,
                child: Padding(
                  padding: EdgeInsets.all(8.0),
                  child: TextField(
                    decoration: InputDecoration(hintText: '\$100'),
                    controller: enteredAmount,
                    keyboardType:
                        TextInputType.numberWithOptions(decimal: true),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              ToggleButtons(
                children: [
                  Text('10%'),
                  Text('15%'),
                  Text('20%'),
                ],
                isSelected: _selection,
                onPressed: UpdateSelection,
              ),
              SizedBox(
                height: 10,
              ),
              TextButton(
                onPressed: CalculateTip,
                child: Text('Calculate'),
                style: TextButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    textStyle: TextStyle(
                      fontSize: 18,
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void UpdateSelection(int selectedIndex) {
    setState(() {
      for (int i = 0; i < _selection.length; i++) {
        _selection[i] = selectedIndex == i;
      }
    });
  }

  void CalculateTip() {
    final totalAmount = double.parse(enteredAmount.text);
    final selectedIndex = _selection.indexWhere((element) => element);
    final tipPrecentage = [0.1, 0.15, 0.2][selectedIndex];
    final totalTip = (totalAmount * tipPrecentage).toStringAsFixed(2);

    setState(() {
      tip = '\$$totalTip';
    });
  }
}
