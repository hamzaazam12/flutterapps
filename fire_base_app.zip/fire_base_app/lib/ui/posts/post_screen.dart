import 'package:fire_base_app/ui/auth/login_screen.dart';
import 'package:fire_base_app/ui/posts/add_posts.dart';
import 'package:fire_base_app/utils/utils.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';

class PostScreen extends StatefulWidget {
  const PostScreen({Key? key}) : super(key: key);

  @override
  State<PostScreen> createState() => _PostScreenState();
}

class _PostScreenState extends State<PostScreen> {
  final databaseRef = FirebaseDatabase.instance.ref('Post');
  final searchController = TextEditingController();
  final editController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final auth = FirebaseAuth.instance;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Post'),
        centerTitle: true,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const LoginScreen(),
                    ));
                auth.signOut();
              },
              icon: const Icon(
                Icons.logout_outlined,
              )),
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 10,
          ),

          Expanded(
            child: FirebaseAnimatedList(
              defaultChild: const Text('Loading'),
              query: databaseRef,
              itemBuilder: (context, snapshot, animation, index) {
                final title = snapshot.child('title').value.toString();
                final id = snapshot.child('id').value.toString();
                return ListTile(
                  title: Text(
                    snapshot.child('title').value.toString(),
                  ),
                  trailing: PopupMenuButton(
                    child: const Icon(Icons.more_vert),
                    itemBuilder: (context) => [
                      PopupMenuItem(
                        value: 1,
                        child: ListTile(
                          onTap: () {
                            Navigator.pop(context);
                            showMyDialogue(title, id);
                          },
                          leading: Icon(Icons.edit),
                          title: Text('Edit'),
                        ),
                      ),
                      PopupMenuItem(
                        value: 1,
                        child: ListTile(
                          onTap: () {
                            databaseRef.child(id).remove();
                            Navigator.pop(context);
                          },
                          leading: Icon(Icons.delete_outline),
                          title: Text('Delete'),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(
          Icons.add,
        ),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AddPost(),
            ),
          );
        },
      ),
    );
  }

  Future<void> showMyDialogue(String title, String id) async {
    editController.text = title;
    return showDialog(
        context: context,
        builder: ((context) {
          return AlertDialog(
            title: Text('Update'),
            content: Container(
              child: TextField(
                controller: editController,
                decoration: InputDecoration(
                  hintText: 'Edit',
                ),
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Cancel')),
              TextButton(
                  onPressed: () {
                    databaseRef.child(id).update({
                      'title': editController.text.toString(),
                    }).then((value) {
                      Utils().showToast('Post Updated');
                      Navigator.pop(context);
                    }).onError((error, stackTrace) {
                      Utils().showToast(error.toString());
                    });
                  },
                  child: Text('Update')),
            ],
          );
        }));
  }
}
