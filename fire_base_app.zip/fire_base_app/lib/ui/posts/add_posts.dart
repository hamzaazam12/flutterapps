import 'package:fire_base_app/ui/posts/post_screen.dart';
import 'package:fire_base_app/utils/utils.dart';
import 'package:fire_base_app/widgets/round_button.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

class AddPost extends StatefulWidget {
  const AddPost({Key? key}) : super(key: key);

  @override
  State<AddPost> createState() => _AddPostState();
}

class _AddPostState extends State<AddPost> {
  final time = DateTime.now().millisecond;
  final databaseRef = FirebaseDatabase.instance.ref('Post');
  bool loading = false;
  final postController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Post'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 20,
        ),
        child: Column(
          children: [
            const SizedBox(
              height: 30,
            ),
            TextFormField(
              maxLines: 4,
              controller: postController,
              decoration: const InputDecoration(
                hintText: 'What is in your mind?',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(
              height: 40,
            ),
            RoundButton(
              title: 'Add',
              loading: loading,
              onTap: () {
                setState(() {
                  loading = true;
                });
                String id = DateTime.now().millisecond.toString();
                databaseRef.child(id).set({
                  'id': id,
                  'title': postController.text.toString(),
                }).then((value) {
                  Navigator.push(context, MaterialPageRoute(
                     builder:  (context)=> PostScreen(),
                  ));
                  setState(() {
                    loading = false;
                  });
                  Utils().showToast('Post Added');
                }).onError((error, stackTrace) {
                  setState(() {
                    loading = false;
                  });
                  Utils().showToast(error.toString());
                });
              },
            )
          ],
        ),
      ),
    );
  }
}
