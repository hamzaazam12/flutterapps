import 'package:fire_base_app/ui/auth/login_with_phone_number.dart';
import 'package:fire_base_app/ui/auth/signup_screen.dart';
import 'package:fire_base_app/ui/posts/post_screen.dart';
import 'package:fire_base_app/utils/utils.dart';
import 'package:fire_base_app/widgets/round_button.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_auth/firebase_auth.dart';


class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool loading = false;
  final _auth = FirebaseAuth.instance;
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _passwordController.dispose();
    _emailController.dispose();
  }

  void login() {
    setState(() {
      loading = true;
    });
    _auth.signInWithEmailAndPassword(
        email: _emailController.text.toString(),
        password: _passwordController.text.toString()).then((value) {
      setState(() {
        loading = false;
      });
          Utils().showToast(value.user!.email.toString());
          Utils().showToast('login Successfull');
          Navigator.push(context,
              MaterialPageRoute(
                  builder: (context)=> PostScreen()));
    }).onError((error, stackTrace){
      Utils().showToast(error.toString());
      setState(() {
        loading = false;
      });
    });
  }
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async{
        SystemNavigator.pop();

        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Text('Login '),
          centerTitle: true,
        ),
        body: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Form(
                key: _formKey,
                  child: Column(
                    children: [
                      TextFormField(
                        decoration: InputDecoration(
                          hintText: '   Email',
                          prefixIcon: Icon(Icons.alternate_email)
                        ),
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        validator: (value) {
                          if(value!.isEmpty){
                            return 'Enter Email';
                          }
                          else {
                            return null;
                          }
                        },
                      ),
                      SizedBox(height: 20,),
                      TextFormField(
                        decoration: InputDecoration(
                            hintText: '   Password',
                            prefixIcon: Icon(Icons.key)
                        ),
                        controller: _passwordController,
                        obscureText: true,
                        keyboardType: TextInputType.text,
                        validator: (value){
                          if(value!.isEmpty) {
                            return 'Enter Password';
                          }else {
                            return null;
                          }
                        },
                      ),
                    ],
                  ),
              ),
              const SizedBox(height: 50,),
              RoundButton(title: 'Login', loading: loading,onTap: (){
                if(_formKey.currentState!.validate()){
                  login();
                }
              },
              ),
              const SizedBox(height: 30,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Don't have an account?"),
                  TextButton( child: Text('Sign up'),
                    onPressed: (){
                    Navigator.push(context,
                        MaterialPageRoute(
                            builder: (context)=> SignUpScreen()));
                    },
                  ),
                ],
              ),
              SizedBox(height: 30),
              InkWell(
                onTap: (){
                  Navigator.push(context,
                      MaterialPageRoute(
                          builder: (context)=> LoginWithPhoneNumber()));
                },
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                    border: Border.all(color: Colors.black),
                  ),

                  child: Center(
                    child: Text('Login with phone'),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
