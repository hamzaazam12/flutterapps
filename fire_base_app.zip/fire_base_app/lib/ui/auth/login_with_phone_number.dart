import 'package:fire_base_app/ui/auth/verify_code.dart';
import 'package:fire_base_app/utils/utils.dart';
import 'package:fire_base_app/widgets/round_button.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';


class LoginWithPhoneNumber extends StatefulWidget {
  const LoginWithPhoneNumber({Key? key}) : super(key: key);

  @override
  State<LoginWithPhoneNumber> createState() => _LoginWithPhoneNumberState();
}

class _LoginWithPhoneNumberState extends State<LoginWithPhoneNumber> {
final _phoneNumberController = TextEditingController();
bool loading = false;
final _auth = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context) {


    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          children: [
            const SizedBox(height: 80,),
            TextFormField(
              keyboardType: TextInputType.number,
              controller: _phoneNumberController,
              decoration: const InputDecoration(
                hintText: '+1 123 324 345'
              ),
            ),
            const SizedBox(height: 80,),
            RoundButton(title: 'Login',loading: loading, onTap: (){
              setState(() {
                loading = true;
              });
              _auth.verifyPhoneNumber(
                  phoneNumber: _phoneNumberController.text,
                  verificationCompleted: (_){
                    setState(() {
                      loading = false;
                    });
                  },
                  verificationFailed: (e){
                    Utils().showToast(e.toString());
                    setState(() {
                      loading = false;
                    });
                  },
                  codeSent: (String verificationId, int? token){
                    Navigator.push(context,
                    MaterialPageRoute(
                        builder: (context)=>
                        VerifyCodeScreen(verificationId: verificationId, )));
                    setState(() {
                      loading = false;
                    });
                  },
                  codeAutoRetrievalTimeout: (e){
                    Utils().showToast(e.toString());
                    setState(() {
                      loading = false;
                    });
                  });
            }),
          ],
        ),
      ),
    );
  }
}
