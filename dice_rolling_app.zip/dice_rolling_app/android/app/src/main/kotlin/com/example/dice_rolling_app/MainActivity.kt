package com.example.dice_rolling_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
